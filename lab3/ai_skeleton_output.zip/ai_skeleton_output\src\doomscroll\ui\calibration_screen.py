# TODO: CalibrationScreen -- guided calibration point sequence [UC 1.2].
# TODO: render current calibration point; advance currentPointIndex on sample collected.
# TODO: wire to CalibrationController (existing gaze/calibration.py logic, not this file).
# TODO: "skip" action -> transition 4 (Reading - Autoscroll Disabled).
# TODO: completion -> transition 3 (Reading - Autoscroll Active).

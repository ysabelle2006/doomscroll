# TODO: ScrollCommand -- direction, speed, timestamp. Currently implicit (direct
#       OSScrollAPI calls in scroll/) -- promote to an explicit value object here.
# TODO: used by AutoscrollController (produces) and OSScrollAPI injectors (consume).

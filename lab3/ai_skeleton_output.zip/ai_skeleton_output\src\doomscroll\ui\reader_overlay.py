# TODO: ReaderOverlay -- always-on-top HUD shown during active reading.
# TODO: frameless, translucent, WindowStaysOnTopHint; replaces the current cv2 debug window.
# TODO: statusIndicator: show autoscroll active/paused state.
# TODO: subscribe to GazeEstimationController's gaze-point signal (see control/ layer).
# TODO: click-through on transparent regions so it never steals focus from the reader's app.

# TODO: tests for the new PySide6 UI layer (pytest-qt once the UI exists to test).

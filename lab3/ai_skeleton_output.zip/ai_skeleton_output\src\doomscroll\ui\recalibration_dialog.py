# TODO: RecalibrationPromptDialog -- modal offering recalibration on sustained low confidence [UC 1.3].
# TODO: triggered by GazeEstimationController when confidence stays below threshold.
# TODO: "Recalibrate now" -> transition 6 (-> Calibration).
# TODO: "Remind me later" -> transition 7 (-> Reading - Autoscroll Active, dismiss only).

# TODO: SettingsScreen -- Autoscroll settings panel [UC 5.1].
# TODO: fields: enabledDirections, sensitivity, speed, confidenceThreshold, pause/resume hotkey.
# TODO: validation (e.g. reject negative speed) per UC 5.1 exception 5.1.EX.1.
# TODO: on save, call SettingsController to persist AutoscrollSettings.
# TODO: "Recalibrate now" button -> transition 14 (-> Calibration).

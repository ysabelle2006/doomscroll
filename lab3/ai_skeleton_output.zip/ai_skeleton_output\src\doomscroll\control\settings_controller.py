# TODO: SettingsController -- reads SettingsScreen input, persists AutoscrollSettings [UC 5.1].
# TODO: load()/save() against a JSON file in platformdirs.user_data_dir("doomscroll").
# TODO: validate incoming values (reject negative speed, out-of-range sensitivity, etc).

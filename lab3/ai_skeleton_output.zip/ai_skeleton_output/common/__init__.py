"""Shared, dependency-free data types used across the Doomscroll packages."""

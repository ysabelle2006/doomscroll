"""Shared lightweight data types used across the Doomscroll packages.

These are plain data holders referenced by multiple packages (gaze,
windowing, content, training) so that none of those packages need to
import from one another just to share a return type.
"""

from dataclasses import dataclass


@dataclass
class LandmarkResult:
    """Facial landmark detection result for a single frame.

    TODO: implement -- expected fields include per-landmark pixel
    coordinates, detection confidence, and the source frame timestamp.
    """
    # TODO: implement
    pass


@dataclass
class WindowBounds:
    """Screen-space bounding box of the focused application window.

    TODO: implement -- expected fields: x, y, width, height (and
    possibly the window/app title).
    """
    # TODO: implement
    pass


@dataclass
class ContentBlock:
    """A single OCR'd / segmented block of on-screen content.

    TODO: implement -- expected fields: block id, bounding box,
    recognized text, and reading-order index.
    """
    # TODO: implement
    pass


@dataclass
class SessionFeatures:
    """Extracted per-session features/labels loaded from
    datasets/features/*.npz.

    TODO: implement -- expected fields: feature matrix, target gaze
    points, and a participant/session grouping id.
    """
    # TODO: implement
    pass

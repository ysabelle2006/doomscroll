"""Entry point: crop eye regions out of recorded session frames."""


def main() -> None:
    # TODO: implement -- read raw recorded frames, run landmark
    # detection, crop/save eye regions for downstream feature building.
    pass


if __name__ == "__main__":
    main()

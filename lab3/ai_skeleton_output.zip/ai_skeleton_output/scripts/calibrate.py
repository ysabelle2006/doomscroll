"""Entry point: run the full on-screen calibration flow and fit a
GazeCalibrator (Math Gaze Model) for the current participant.
"""

from gaze.gaze_calibrator import GazeCalibrator


def main() -> None:
    # TODO: implement -- collect calibration points/features, call
    # GazeCalibrator.fit(...), then GazeCalibrator.save(...).
    pass


if __name__ == "__main__":
    main()

"""Entry point: turn recorded sessions + eye crops into feature/label
.npz files under datasets/features/, consumable by FeatureDataset.
"""

from recording.session import SessionIdentity


def main() -> None:
    # TODO: implement -- use SessionIdentity to label each recording's
    # samples with its participant/session id, then write
    # datasets/features/*.npz.
    pass


if __name__ == "__main__":
    main()

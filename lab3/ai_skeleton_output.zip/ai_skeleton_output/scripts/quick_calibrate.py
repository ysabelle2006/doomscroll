"""Entry point: a shortened calibration flow used by the Quick Start path."""

from gaze.gaze_calibrator import GazeCalibrator


def main() -> None:
    # TODO: implement -- abbreviated version of calibrate.py's flow.
    pass


if __name__ == "__main__":
    main()

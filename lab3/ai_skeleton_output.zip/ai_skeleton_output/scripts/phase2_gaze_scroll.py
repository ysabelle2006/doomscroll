"""Entry point: the live runtime loop -- webcam capture, the landmark /
head-pose / gaze pipeline, window-bounds + content scanning, the
scroll-trigger decision, and scroll injection. This is what Quick
Start / Full Start ultimately run.
"""

from content.background_scanner import BackgroundContentScanner
from content.content_gaze_tracker import ContentGazeTracker
from content.scroll_trigger import ScrollTrigger
from gaze.attention_gate import AttentionGate
from gaze.gaze_calibrator import GazeCalibrator
from gaze.head_pose import HeadPoseEstimator
from gaze.landmarks import MediaPipeLandmarkBackend
from gaze.smoothing import GazePointSmoother
from gaze.trained_gaze_model import TrainedGazeModel


def _build_window_bounds_provider():
    # TODO: implement -- pick windowing.MacOSWindowBoundsProvider or
    # windowing.WindowsWindowBoundsProvider based on platform.system().
    pass


def _build_scroll_injector():
    # TODO: implement -- pick scroll.MacOSScrollInjector or
    # scroll.WindowsScrollInjector based on platform.system().
    pass


def _build_content_scanner():
    # TODO: implement -- content.MacOSVisionContentScanner on macOS,
    # else None.
    pass


def main() -> None:
    # TODO: implement -- wire together MediaPipeLandmarkBackend,
    # HeadPoseEstimator, a gaze model (GazeCalibrator or
    # TrainedGazeModel, chosen per Quick Start vs. Full Start),
    # GazePointSmoother, AttentionGate, BackgroundContentScanner,
    # ScrollTrigger, and a ScrollInjector into the live per-frame loop.
    pass


if __name__ == "__main__":
    main()

"""Entry point: record a webcam + on-screen-target session for the
current participant, to be turned into training features later.
"""

from recording.session import SessionIdentity


def main() -> None:
    # TODO: implement -- resolve participant/session id via
    # SessionIdentity, drive the capture loop, and write raw
    # frames/targets to disk for build_crops.py / build_dataset.py.
    pass


if __name__ == "__main__":
    main()

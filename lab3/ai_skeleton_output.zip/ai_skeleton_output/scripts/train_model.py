"""Entry point: estimate webcam/gaze lag and write it into
models/gaze_model.joblib. Thin wrapper around training.lag_estimator.LagEstimator.
"""

from pathlib import Path

from training.feature_dataset import FeatureDataset
from training.lag_estimator import LagEstimator

DATASET_DIR = Path("datasets/features")


def main() -> None:
    # TODO: implement -- sessions = FeatureDataset.load_all(DATASET_DIR);
    # LagEstimator(sessions).main().
    pass


if __name__ == "__main__":
    main()

"""Entry point: train the CNN gaze model. Thin wrapper around
training.cnn_trainer.CnnTrainer.
"""

from pathlib import Path

from training.cnn_trainer import CnnTrainer
from training.feature_dataset import FeatureDataset

DATASET_DIR = Path("datasets/features")


def main() -> None:
    # TODO: implement -- sessions = FeatureDataset.load_all(DATASET_DIR);
    # model = CnnTrainer(sessions).train(); persist the result.
    pass


if __name__ == "__main__":
    main()

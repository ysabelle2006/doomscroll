"""Scripts package: standalone entry points spawned as subprocesses by
app.command_runner.CommandRunner (see app.script_subprocess for their
paths). Each module here is a thin wrapper around the real library code
in gaze/, content/, scroll/, recording/, and training/.
"""

"""Trains the CNN gaze model (models/gaze_cnn.pt). Backs scripts/train_cnn.py."""

from pathlib import Path
from typing import List

from common.types import SessionFeatures
from gaze.trained_gaze_model import TrainedGazeModel

MODEL_PATH = Path("models/gaze_cnn.pt")
LAG_MODEL_PATH = Path("models/gaze_model.joblib")


class CnnTrainer:
    """<<scripts/train_cnn.py>>"""

    def __init__(self, sessions: List[SessionFeatures]) -> None:
        # TODO: implement
        pass

    def default_lag(self) -> float:
        # TODO: implement -- read lag_ms from LAG_MODEL_PATH (written by
        # LagEstimator), falling back to a hardcoded default if absent.
        pass

    def train(self) -> TrainedGazeModel:
        # TODO: implement -- build a CnnBackbone, train on self sessions
        # (time-shifted by default_lag()), save weights to MODEL_PATH,
        # return the resulting TrainedGazeModel.
        pass

"""Training package: feature-dataset loading, lag estimation, and CNN
gaze-model training.
"""

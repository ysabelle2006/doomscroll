"""Sweeps candidate webcam/gaze latency values and picks the best lag,
writing lag_ms into models/gaze_model.joblib. Backs scripts/train_model.py.
"""

from pathlib import Path
from typing import List

from common.types import SessionFeatures

MODEL_PATH = Path("models/gaze_model.joblib")


class LagEstimator:
    """<<scripts/train_model.py>>"""

    def __init__(self, sessions: List[SessionFeatures]) -> None:
        # TODO: implement
        pass

    def sweep(self) -> float:
        # TODO: implement -- try a range of lag values, score each
        # against self sessions, return the best lag in milliseconds.
        pass

    def main(self) -> None:
        # TODO: implement -- run sweep() and persist the resulting
        # lag_ms into MODEL_PATH.
        pass

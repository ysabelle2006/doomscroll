"""Loads extracted per-session feature/label sets from
datasets/features/*.npz.
"""

from pathlib import Path
from typing import List

from common.types import SessionFeatures


class FeatureDataset:
    """<<datasets/features/*.npz>>"""

    @staticmethod
    def load_all(dir: Path) -> List[SessionFeatures]:
        # TODO: implement -- glob datasets/features/*.npz under dir and
        # load each into a SessionFeatures.
        pass

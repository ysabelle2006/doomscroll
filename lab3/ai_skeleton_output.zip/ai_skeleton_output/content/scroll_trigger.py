"""Three-tier scroll decision:
  tier 1: viewport-bounds / dwell-time heuristic (no content scanning)
  tiers 2 & 3: content-block gaze coverage, via ContentGazeTracker,
               fed by BackgroundContentScanner when available
On a positive decision, fires a ScrollInjector.scroll() call.
"""

from typing import Any, List, Tuple

from common.types import ContentBlock
from content.content_gaze_tracker import ContentGazeTracker
from scroll.scroll_injector import ScrollInjector


class ScrollTrigger:
    """<<3-tier decision>>"""

    def __init__(self, tracker: ContentGazeTracker, injector: ScrollInjector) -> None:
        # TODO: implement -- store tracker and injector, init dwell/
        # cooldown state.
        pass

    def update(
        self,
        fy: float,
        blocks: List[ContentBlock],
        point: Any,
        viewport_bottom: float,
        ts: float,
        content_available: bool,
    ) -> Tuple[bool, str]:
        # TODO: implement -- decide (should_fire, tier_label) using the
        # tier-1 viewport heuristic when not content_available, else
        # delegate to self._tracker for tiers 2/3; call
        # self._injector.scroll(...) when should_fire is True.
        pass

    def reset_dwell(self) -> None:
        # TODO: implement
        pass

    def note_scroll_fired(self, ts: float) -> None:
        # TODO: implement -- record cooldown bookkeeping after a scroll.
        pass

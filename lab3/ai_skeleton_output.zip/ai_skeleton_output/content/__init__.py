"""Content package: macOS OCR content scanning, background polling,
per-content gaze tracking, and the scroll-trigger decision logic.
"""

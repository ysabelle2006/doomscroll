"""Interface for scanning a window's content into discrete blocks
(macOS only).
"""

from abc import ABC, abstractmethod
from typing import List

from common.types import ContentBlock, WindowBounds


class ContentScanner(ABC):
    """<<interface, macOS only>>"""

    @abstractmethod
    def scan(self, bounds: WindowBounds) -> List[ContentBlock]:
        # TODO: implement in a concrete subclass
        raise NotImplementedError

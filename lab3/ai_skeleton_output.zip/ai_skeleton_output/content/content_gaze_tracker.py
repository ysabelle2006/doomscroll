"""Tracks which content blocks the user's gaze has already visited
within the current viewport, backing ScrollTrigger tiers 2 & 3.
"""

from typing import Any, FrozenSet, List

from common.types import ContentBlock


class ContentGazeTracker:
    def __init__(self) -> None:
        self.seen_ids: FrozenSet[str] = frozenset()
        # TODO: implement

    def update(self, blocks: List[ContentBlock], gaze_point: Any, ts: float) -> None:
        # TODO: implement -- mark blocks under/near gaze_point as seen.
        pass

    def has_reached_end(self) -> bool:
        # TODO: implement -- True once the last known block has been seen.
        pass

    def should_scroll(self) -> bool:
        # TODO: implement -- True once enough visible content has been
        # read to justify scrolling.
        pass

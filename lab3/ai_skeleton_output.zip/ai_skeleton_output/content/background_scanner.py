"""Polls a ContentScanner (if available on this platform) on its own
background thread roughly every 0.4s and caches the latest blocks.
"""

from typing import List, Optional

from common.types import ContentBlock
from content.content_scanner import ContentScanner

POLL_INTERVAL_SECONDS = 0.4


class BackgroundContentScanner:
    """<<polls every ~0.4s on its own thread>>"""

    def __init__(self, scanner: Optional[ContentScanner] = None) -> None:
        # TODO: implement -- store scanner (None on platforms without
        # one), start/own the background polling thread.
        pass

    def start(self) -> None:
        # TODO: implement
        pass

    def stop(self) -> None:
        # TODO: implement
        pass

    def latest_blocks(self) -> List[ContentBlock]:
        # TODO: implement -- return the most recently polled blocks
        # (thread-safe read).
        pass

"""macOS Apple Vision-backed OCR content scanner."""

from typing import List

from common.types import ContentBlock, WindowBounds
from content.content_scanner import ContentScanner


class MacOSVisionContentScanner(ContentScanner):
    """<<Apple Vision OCR>>"""

    def scan(self, bounds: WindowBounds) -> List[ContentBlock]:
        # TODO: implement -- capture bounds, run Apple Vision OCR/text
        # detection, return recognized ContentBlocks.
        pass

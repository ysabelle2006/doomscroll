"""macOS scroll injection via Quartz CGEvent."""

from typing import Any, Optional

from scroll.scroll_injector import ScrollInjector


class MacOSScrollInjector(ScrollInjector):
    """<<Quartz CGEvent>>"""

    def scroll(self, dx: float, dy: float, unit: str, target_point: Optional[Any] = None) -> None:
        # TODO: implement -- build and post a CGEvent scroll wheel event.
        pass

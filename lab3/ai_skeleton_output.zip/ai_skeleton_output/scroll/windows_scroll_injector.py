"""Windows scroll injection via win32api."""

from typing import Any, Optional

from scroll.scroll_injector import ScrollInjector


class WindowsScrollInjector(ScrollInjector):
    """<<win32api>>"""

    def scroll(self, dx: float, dy: float, unit: str, target_point: Optional[Any] = None) -> None:
        # TODO: implement -- call win32api.mouse_event with a wheel delta.
        pass

"""Scroll package: per-OS synthetic scroll event injection."""

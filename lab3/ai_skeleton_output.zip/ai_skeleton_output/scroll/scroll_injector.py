"""Interface for injecting a synthetic scroll event into the OS."""

from abc import ABC, abstractmethod
from typing import Any, Optional


class ScrollInjector(ABC):
    """<<interface>>"""

    @abstractmethod
    def scroll(self, dx: float, dy: float, unit: str, target_point: Optional[Any] = None) -> None:
        # TODO: implement in a concrete subclass
        raise NotImplementedError

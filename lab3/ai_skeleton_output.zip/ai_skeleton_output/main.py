"""Doomscroll desktop app entry point.

Launches the Tkinter GUI (App). All actual work (recording, training,
calibrating, and the live gaze-scroll loop) happens in subprocesses
spawned by CommandRunner via the scripts in scripts/.
"""

from app.main_app import main as launch_app


if __name__ == "__main__":
    launch_app()

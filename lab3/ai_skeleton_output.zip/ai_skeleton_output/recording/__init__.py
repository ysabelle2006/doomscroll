"""Recording package: participant/session identity for labeling recordings."""

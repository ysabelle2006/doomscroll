"""Session/participant identity helpers used to label recordings."""


class SessionIdentity:
    """<<recording/session.py>>"""

    @staticmethod
    def get_default_participant() -> str:
        # TODO: implement -- derive a default participant name/id (e.g.
        # from the OS username).
        pass

    @staticmethod
    def participant_hashid(participant: str) -> str:
        # TODO: implement -- return a stable, de-identified hash of the
        # participant name.
        pass

    @staticmethod
    def make_session_id(hashid: str) -> str:
        # TODO: implement -- combine hashid with a timestamp to produce
        # a unique session id.
        pass

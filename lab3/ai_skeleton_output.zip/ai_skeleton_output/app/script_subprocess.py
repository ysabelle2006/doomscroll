"""Logical grouping for the standalone step scripts under scripts/.

Each of these is a plain Python script spawned as its own subprocess
by CommandRunner rather than imported as library code. This module
centralizes their paths and command-building so CommandRunner/App do
not hardcode path strings.
"""

from pathlib import Path
from typing import List, Sequence


class ScriptSubprocess:
    """<<scripts/*.py, spawned per step>>"""

    SCRIPTS_DIR = Path("scripts")

    RECORD_SESSION = SCRIPTS_DIR / "record_session.py"
    BUILD_CROPS = SCRIPTS_DIR / "build_crops.py"
    BUILD_DATASET = SCRIPTS_DIR / "build_dataset.py"
    CALIBRATE = SCRIPTS_DIR / "calibrate.py"
    QUICK_CALIBRATE = SCRIPTS_DIR / "quick_calibrate.py"
    TRAIN_CNN = SCRIPTS_DIR / "train_cnn.py"
    TRAIN_MODEL = SCRIPTS_DIR / "train_model.py"
    PHASE2_GAZE_SCROLL = SCRIPTS_DIR / "phase2_gaze_scroll.py"

    @staticmethod
    def build_command(script_path: Path, args: Sequence[str] = ()) -> List[str]:
        # TODO: implement -- return e.g.
        # [sys.executable, str(script_path), *args]
        pass

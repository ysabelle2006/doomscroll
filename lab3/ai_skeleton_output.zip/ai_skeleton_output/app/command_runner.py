"""Runs the step scripts described in app.script_subprocess as
subprocesses and streams their stdout/stderr into a thread-safe queue
that the UI polls to update its log view.
"""

import queue
from typing import List, Sequence, Tuple


class CommandRunner:
    """Spawns ScriptSubprocess commands and streams output to the Log."""

    def __init__(self) -> None:
        self.log_queue: "queue.Queue[str]" = queue.Queue()
        # TODO: implement

    def run_cmd(self, label: str, cmd: Sequence[str]) -> bool:
        # TODO: implement -- spawn cmd as a subprocess, stream its
        # output lines (prefixed with label) into self.log_queue, and
        # return whether it exited successfully.
        pass

    def run_cmd_capture(self, label: str, cmd: Sequence[str]) -> Tuple[bool, List[str]]:
        # TODO: implement -- like run_cmd, but also return the full
        # captured output lines to the caller.
        pass

    def ask_calibration_checkpoint(self) -> str:
        # TODO: implement -- prompt the user (via the UI) whether to
        # keep, redo, or skip an in-progress calibration checkpoint;
        # return the user's choice.
        pass

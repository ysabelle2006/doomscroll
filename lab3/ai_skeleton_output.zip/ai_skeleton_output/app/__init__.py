"""App package: the Tkinter launcher UI and the command runner that
drives the standalone step scripts in scripts/.
"""

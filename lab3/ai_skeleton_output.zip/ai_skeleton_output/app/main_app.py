"""Tkinter launcher window for Doomscroll.

Hosts the main page (Quick Start / Record, train & calibrate /
Calibrate only / Clear calibrations) and a settings page, and routes
every button press through a CommandRunner so the UI thread never
blocks on a long-running step script.
"""

import tkinter as tk

from app.command_runner import CommandRunner


class App:
    """<<Tk launcher>>"""

    def __init__(self) -> None:
        self.root: tk.Tk
        self.runner: CommandRunner
        # TODO: implement -- construct self.root, instantiate
        # self.runner, and build the initial page.

    def _build_main_page(self) -> None:
        # TODO: implement
        pass

    def _build_settings_page(self) -> None:
        # TODO: implement
        pass

    def _on_quick_start(self) -> None:
        # TODO: implement -- run scripts/quick_calibrate.py then
        # scripts/phase2_gaze_scroll.py via self.runner.
        pass

    def _on_record_and_train(self) -> None:
        # TODO: implement -- run record_session.py, build_crops.py,
        # build_dataset.py, train_cnn.py, train_model.py, calibrate.py
        # in sequence via self.runner.
        pass

    def _on_calibrate_only(self) -> None:
        # TODO: implement -- run scripts/calibrate.py via self.runner.
        pass

    def _on_clear_calibrations(self) -> None:
        # TODO: implement -- delete saved calibration/model artifacts.
        pass


def main() -> None:
    # TODO: implement -- instantiate App() and start the Tk mainloop.
    pass


if __name__ == "__main__":
    main()

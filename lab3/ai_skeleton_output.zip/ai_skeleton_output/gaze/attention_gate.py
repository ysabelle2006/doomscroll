"""Pauses scroll automation when head pose indicates the user is not
attending to the screen (e.g. looked away or turned aside).
"""

from gaze.head_pose import HeadPose


class AttentionGate:
    def __init__(self) -> None:
        # TODO: implement
        pass

    def update(self, head_pose: HeadPose, ts: float) -> bool:
        # TODO: implement -- return True ("paused") if automation should
        # be paused given the current head pose/timestamp.
        pass

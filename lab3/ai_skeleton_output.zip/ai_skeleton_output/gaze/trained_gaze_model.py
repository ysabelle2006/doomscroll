"""CNN-based gaze model ("CNN Gaze Model") with an optional small
per-user affine correction layered on top of the network's raw
prediction.
"""

from typing import Any, Optional

import torch
from torch import nn

from gaze.head_pose import HeadPose


class CnnBackbone(nn.Module):
    """Convolutional backbone predicting a raw gaze point from an eye crop."""

    def __init__(self) -> None:
        super().__init__()
        # TODO: implement -- define conv/linear layers.

    def forward(self, x: Any) -> Any:
        # TODO: implement
        pass


class AffineCorrection:
    """Small per-user affine correction fit on top of the CNN's output."""

    def __init__(self) -> None:
        # TODO: implement
        pass

    def apply(self, point: Any) -> Any:
        # TODO: implement
        pass


class TrainedGazeModel:
    """<<CNN Gaze Model>>"""

    def __init__(self) -> None:
        self.net: CnnBackbone
        self.correction: Optional[AffineCorrection]
        # TODO: implement

    def predict_px(
        self,
        points_px: Any,
        head_pose: HeadPose,
        gray: Any,
        screen_size: Any,
    ) -> Any:
        # TODO: implement -- crop eye region(s) from gray using
        # points_px, run self.net, optionally apply self.correction,
        # return an ndarray [x, y] in screen pixels.
        pass

    @classmethod
    def load_gaze_model(cls, path: str, with_correction: bool) -> "TrainedGazeModel":
        # TODO: implement -- load weights from path (models/gaze_cnn.pt)
        # and, if with_correction, the fitted AffineCorrection.
        pass

"""MediaPipe-backed facial landmark detection."""

from typing import Any

from common.types import LandmarkResult


class MediaPipeLandmarkBackend:
    """Wraps a MediaPipe FaceMesh (or similar) landmark model."""

    def __init__(self) -> None:
        # TODO: implement -- construct/configure the MediaPipe model.
        pass

    def detect(self, frame: Any, ts: float) -> LandmarkResult:
        # TODO: implement -- run landmark detection on frame, return
        # pixel-space landmark points for this timestamp.
        pass

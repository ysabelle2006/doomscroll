"""Interface for extracting a raw gaze feature vector from a frame.

Implemented by whatever eye-region feature extractor feeds the
ridge-regression "Math" gaze model (GazeCalibrator).
"""

from abc import ABC, abstractmethod
from typing import Any


class GazeVectorExtractor(ABC):
    """<<interface>>"""

    @abstractmethod
    def extract(self, frame: Any, gray: Any, points_px: Any) -> Any:
        # TODO: implement in a concrete subclass -- return an ndarray
        # gaze feature vector derived from the eye region(s).
        raise NotImplementedError

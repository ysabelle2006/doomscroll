"""Gaze package: landmark detection, head pose, the two interchangeable
gaze models (ridge-regression "Math" model and CNN model), smoothing,
and attention gating.
"""

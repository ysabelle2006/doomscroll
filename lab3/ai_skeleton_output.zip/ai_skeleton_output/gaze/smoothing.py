"""Temporal smoothing of raw gaze points (Kalman filter + EMA)."""

from typing import Any


class GazePointSmoother:
    """<<Kalman + EMA>>"""

    def __init__(self) -> None:
        # TODO: implement -- initialize Kalman filter state and EMA state.
        pass

    def update(self, point: Any, ts: float) -> Any:
        # TODO: implement -- feed a new raw point/timestamp through the
        # Kalman filter and EMA, return the smoothed ndarray point.
        pass

    def reset(self) -> None:
        # TODO: implement
        pass

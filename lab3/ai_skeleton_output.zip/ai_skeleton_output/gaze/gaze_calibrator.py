"""Per-user ridge-regression gaze model ("Math Gaze Model")."""

from typing import Any

from sklearn.linear_model import RidgeCV


class GazeCalibrator:
    """<<Math Gaze Model>>"""

    def __init__(self) -> None:
        self.ridge_x: RidgeCV
        self.ridge_y: RidgeCV
        # TODO: implement

    def fit(self, features: Any, targets: Any, groups: Any) -> None:
        # TODO: implement -- fit ridge_x/ridge_y on calibration features
        # (gaze vector + head pose) against on-screen targets, grouped
        # by calibration session.
        pass

    def predict(self, feature: Any) -> Any:
        # TODO: implement -- return an ndarray [x, y] screen-point
        # prediction for a single feature vector.
        pass

    def validate(self, features: Any, targets: Any) -> float:
        # TODO: implement -- return a validation error/score.
        pass

    @staticmethod
    def save(calibrator: "GazeCalibrator", path: str) -> None:
        # TODO: implement
        pass

    @staticmethod
    def load(path: str) -> "GazeCalibrator":
        # TODO: implement
        pass

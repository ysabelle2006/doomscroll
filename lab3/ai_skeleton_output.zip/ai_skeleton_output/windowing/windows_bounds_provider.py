"""Windows implementation of WindowBoundsProvider (win32gui)."""

from common.types import WindowBounds
from windowing.bounds_provider import WindowBoundsProvider


class WindowsWindowBoundsProvider(WindowBoundsProvider):
    def get_focused_window_bounds(self) -> WindowBounds:
        # TODO: implement -- use win32gui to find the foreground window
        # and return its bounds.
        pass

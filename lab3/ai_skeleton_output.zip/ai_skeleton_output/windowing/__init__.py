"""Windowing package: per-OS lookup of the focused window's screen bounds."""

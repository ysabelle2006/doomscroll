"""Interface for retrieving the focused window's screen bounds."""

from abc import ABC, abstractmethod

from common.types import WindowBounds


class WindowBoundsProvider(ABC):
    """<<interface>>"""

    @abstractmethod
    def get_focused_window_bounds(self) -> WindowBounds:
        # TODO: implement in a concrete subclass
        raise NotImplementedError

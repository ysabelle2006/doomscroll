"""macOS implementation of WindowBoundsProvider (Quartz/AppKit)."""

from common.types import WindowBounds
from windowing.bounds_provider import WindowBoundsProvider


class MacOSWindowBoundsProvider(WindowBoundsProvider):
    def get_focused_window_bounds(self) -> WindowBounds:
        # TODO: implement -- use Quartz/AppKit to find the frontmost
        # window and return its bounds.
        pass

# TODO: User -- userId; associated with one CalibrationProfile, one AutoscrollSettings,
#       and one or more Sessions. No persistence decided yet (single-user desktop app --
#       may not need more than an implicit "current user" until multi-profile support matters).

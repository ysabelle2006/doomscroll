# TODO: SetupScreen -- first-run screen, requests camera permission [UC 1.1].
# TODO: detect current camera-permission state on open.
# TODO: "Allow"/"Not now" actions -> transitions 1 / 2 in the dialog map.
# TODO: on allow, hand off to CalibrationScreen.

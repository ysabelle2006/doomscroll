# TODO: AutoscrollSettings -- enabledDirections, sensitivity, speed, confidenceThreshold.
# TODO: decide dataclass vs pydantic model (project already depends on pydantic>=2).
# TODO: default values; JSON (de)serialization for SettingsController.

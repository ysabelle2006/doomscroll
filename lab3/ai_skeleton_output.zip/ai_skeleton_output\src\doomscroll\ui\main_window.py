# TODO: application composition root for the UI layer (the "start-up class", Fox heuristic).
# TODO: construct QApplication, wire up SetupScreen -> CalibrationScreen -> ReaderOverlay flow.
# TODO: start the capture/inference loop (QTimer or QThread -- see architecture doc, Lab 3).
# TODO: connect AutoscrollController's signals to ReaderOverlay's status indicator.

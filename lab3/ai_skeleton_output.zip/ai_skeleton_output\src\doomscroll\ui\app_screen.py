# TODO: AppScreen -- abstract base class for all top-level application screens.
# TODO: define shared show/hide/lifecycle behaviour common to SetupScreen,
#       CalibrationScreen, SettingsScreen, ReaderOverlay, RecalibrationPromptDialog.
# TODO: decide base Qt class (QWidget vs QDialog) once concrete screens are drafted.

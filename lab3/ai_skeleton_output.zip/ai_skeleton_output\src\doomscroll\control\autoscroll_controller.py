# TODO: AutoscrollController -- promote the dwell-trigger logic currently inline in
#       scripts/phase2_gaze_scroll.py into this real class [UC 4.1].
# TODO: inputs: current GazePoint (+ confidence) from GazeEstimationController,
#       current ImportantContentRegion from ContentAnalysisController (once built).
# TODO: output: emit ScrollCommand objects (direction, speed, timestamp) rather than
#       calling the OSScrollAPI injector directly.
# TODO: pause()/resume() -- UC 5.2.
